# EmberPlay (FlashGameLauncher)
Lanzador Android con dos ventanas independientes (A/B), Ruffle y recarga ante error de carga.

## Compilar el APK solo con GitHub (sin PC)
1. Crea un repositorio y sube el contenido de esta carpeta (Add file > Upload files).
2. Pestaña **Actions** > **Build APK** > **Run workflow** (también corre en cada push).
3. Al terminar, abre la ejecución > **Artifacts** > `EmberPlay-APK` y descarga el .apk.
Comando que ejecuta el workflow: `gradle assembleDebug`.

## Notas
- Ventana B corre en otro proceso con `WebView.setDataDirectorySuffix("b")`: cookies y almacenamiento aislados (Android 9+; en Android 7-8 no hay aislamiento garantizado).
- Ruffle se descarga en el workflow (npm @ruffle-rs/ruffle). Si cambia su estructura, revisa `app/src/main/assets/ruffle/ruffle.js`.
- Naruto Online no está garantizado en Ruffle; el modo remoto no está implementado todavía.
